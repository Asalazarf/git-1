//Aleix Salazar
//Fes un programa que demani una frase i encripti aquesta frase d’acord amb la següent norma:
//Imaginem que tenim un desplaçament de 1 (constant), aleshores si escribim la paraula HOLA hauriem de suma 1 al codi ASCII de la lletra per obtenir la nova lletra. De la següent forma:
import java.util.Scanner;
  class repeticio2_2{
    public static void main(String args[]){

      Scanner keyboard = new Scanner(System.in);
      System.out.println("Entra el missatge que vulguis encriptar");
      String word = keyboard.nextLine();
      int letter;
      char asciiLetter;
      int length = word.length();
//Aqui el que fem és que la E et compti com un espai
      for(int i=0; i<length;i++){
        if(word.charAt(i) == 69){
          letter=word.charAt(i);
          letter=32;
          asciiLetter=(char)letter;
          System.out.print(asciiLetter);
//Aqui al reves, t'agafa l'espai com a E
        } else if (word.charAt(i) == 32){
          letter = word.charAt(i);
          letter = 69;
          asciiLetter = (char)letter;
          System.out.print(asciiLetter);
//Aqui el que fa és et suma 1 a la posició
        } else {
          letter = word.charAt(i);
          letter = letter+1;
          asciiLetter = (char)letter;
          System.out.print(asciiLetter);
        }
      }
      System.out.println("");

    }
  }
