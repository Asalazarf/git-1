import java.util.Scanner;
import java.util.Random;
  public class repeticio2_1 {
    public static void main(String[] args) {

      Scanner keyboard = new Scanner(System.in);
      Random rndm = new Random();
      int player;
      int computer;
      int gamerV=0;
      int pcV=0;
//Definim les variables
      while(gamerV !=3 && pcV !=3){ //Definim un comptador i com a màxim arribarà a 3
        System.out.println("pedra(0), paper(1), tisores(2) ");
        System.out.println("Entra una opció ");
        player=keyboard.nextInt();
        System.out.println("La tirada de l'ordinador és: ");
        computer= rndm.nextInt(3);
        System.out.println(computer);
  //Escribim un nombre i l'ordinador generarà un altre aleatori del 0 al 2
        if(player == 0 && computer == 1){
          System.out.println("El jugador ha tret pedra i l'ordinador paper, guanya l'ordinador");
          pcV++; //el que es fa aquí és obrir un comptador per cadascú, i en cas que guanyi un o l'altre suma fins a 3 victories
        }
        else if(player == 0 && computer == 0){
          System.out.println("El jugador ha tret pedra i l'ordinador pedra, hi ha empat");
        }

        else if(player == 0 && computer == 2){
          System.out.println("El jugador ha tret pedra i l'ordinador tisores, guanya el jugador");
          gamerV++;
        }
        else if(player == 1 && computer == 0){
          System.out.println("El jugador ha tret paper i l'ordinador pedra, guanya el jugador");
          gamerV++;
        }
        else if(player == 1 && computer == 1){
          System.out.println("El jugador ha tret paper i l'ordinador paper, hi ha empat");
        }
        else if(player == 1 && computer == 2){
          System.out.println("El jugador ha tret paper i l'ordinador tisores, guanya l'ordinador");
          pcV++;
        }
        else if(player == 2 && computer == 0){
          System.out.println("El jugador ha tret tisores i l'ordinador pedra, guanya l'ordinador");
          pcV++;
        }
        else if(player == 2 && computer == 1){
          System.out.println("El jugador ha tret tisores i l'ordinador paper, guanya el jugador");
          gamerV++;
        }
        else if(player == 2 && computer == 2){
          System.out.println("El jugador ha tret tisores i l'ordinador tisores, hi ha empat");
        }
      } System.out.println("El jugador ha guanyat "+gamerV+" vegades");
        System.out.println("El ordinador ha guanyat "+pcV+" vegades");
    }
}
