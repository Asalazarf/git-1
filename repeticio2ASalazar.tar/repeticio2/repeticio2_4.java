//Aleix Salazar
//Joc d'enfonsar vaixells. Pinta un taulell de 4 x 4. Genera aleatòriament un vaixell en una de les caselles, però no l'ensenyis, i a continuació demana a l'usuari que entri una coordenada en el format B1, A4 ... Si encerta la casella on està el vaixell GUANYA: TOCAT i ENFONSAT i acaba el joc. sinó diu B1 = AIGUA i segueix jugant.
import java.util.Random;
import java.util.Scanner;

  class repeticio2_4{
    public static void main(String args[]){

      Scanner keyboard = new Scanner(System.in);
      Random rndm;
      String Ans;
      int num = 0;
      int rows = 4;
      int columns = 4;

      System.out.println("Escriu una opció");
      Ans = keyboard.nextLine();

      for(int i = 0; i <= rows; i++){
        if(i==0){
          System.out.println("   A B C D");
        } else{
          System.out.println(i+"  * * * *");
        }
      }
    }
  }
